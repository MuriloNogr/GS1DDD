package br.com.fiap.projectaildly;

import java.util.ArrayList;
import java.util.List;

class PessoaJuridica extends Cadastro {
    private String cnpj;
    private List<String> doacoes;

    public PessoaJuridica(String nome, String endereco, String cnpj) {
        super(nome, endereco);
        this.cnpj = cnpj;
        this.doacoes = new ArrayList<>();
    }
    
    public PessoaJuridica() {
    	
    }
    @Override
    public void cadastrar() {
        System.out.println("Cadastro de Pessoa Jur�dica");
        System.out.println("CNPJ: " + cnpj);
        System.out.println("Nome: " + nome);
        System.out.println("Endere�o: " + endereco);
        System.out.println("Cadastro de Pessoa Jur�dica conclu�do!");
    }

    public void fazerDoacao(String tipoDoacao, String doacao) {
        String registroDoacao = "Nome: " + nome + ", CNPJ: " + cnpj + ", Endere�o: " + endereco + ", Doa��o: " + tipoDoacao + " - " + doacao;
        doacoes.add(registroDoacao);

        System.out.println("Doa��o realizada com sucesso!");
    }

    public void imprimirDoacoes() {
        System.out.println("Doa��es realizadas por " + nome + " - CNPJ: " + cnpj);
        for (String doacao : doacoes) {
            System.out.println(doacao);
        }
    }
}
