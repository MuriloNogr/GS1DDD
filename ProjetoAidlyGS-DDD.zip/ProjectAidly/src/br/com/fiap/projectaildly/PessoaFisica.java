package br.com.fiap.projectaildly;

import java.util.ArrayList;
import java.util.List;

class PessoaFisica extends Cadastro {
    private String cpf;
    private List<String> doacoes;

    public PessoaFisica(String nome, String endereco, String cpf) {
        super(nome, endereco);
        this.cpf = cpf;
        this.doacoes = new ArrayList<>();
    }
    
    public PessoaFisica() {
    	
    }

    @Override
    public void cadastrar() {
        System.out.println("Cadastro de Pessoa F�sica");
        System.out.println("CPF: " + cpf);
        System.out.println("Nome: " + nome);
        System.out.println("Endere�o: " + endereco);
        System.out.println("Cadastro de Pessoa F�sica conclu�do!");
    }

    public void fazerDoacao(String tipoDoacao, String doacao) {
        String registroDoacao = "Nome: " + nome + ", CPF: " + cpf + ", Endere�o: " + endereco + ", Doa��o: " + tipoDoacao + " - " + doacao;
        doacoes.add(registroDoacao);

        System.out.println("Doa��o realizada com sucesso!");
    }

    public void imprimirDoacoes() {
        System.out.println("Doa��es realizadas por " + nome + " - CPF: " + cpf);
        for (String doacao : doacoes) {
            System.out.println(doacao);
        }
    }
}
