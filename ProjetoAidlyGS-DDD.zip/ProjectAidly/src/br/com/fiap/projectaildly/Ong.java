package br.com.fiap.projectaildly;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


class Ong extends Cadastro {
    private String cnpj;
    private List<String> requisicoes;

    public Ong(String nome, String endereco, String cnpj) {
        super(nome, endereco);
        this.cnpj = cnpj;
        this.requisicoes = new ArrayList<>();
    }
    
    public Ong() {
    	
    }

    @Override
    public void cadastrar() {
        System.out.println("Cadastro de ONG");
        System.out.println("CNPJ: " + cnpj);
        System.out.println("Nome: " + nome);
        System.out.println("Endere�o: " + endereco);
        System.out.println("Cadastro de ONG conclu�do!");
    }

    public void criarRequisicao() {
        @SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
        System.out.println("Criar Requisi��o");
        System.out.print("Informe a necessidade: ");
        String necessidade = scanner.nextLine();
        requisicoes.add(necessidade);
        System.out.println("Requisi��o criada!");
    }
    
    public void requisicaoExemplo(String requisicao) {
        requisicoes.add(requisicao);
    }
    
 

    public void imprimirRequisicoes() {
        System.out.println("Requisi��es da ONG " + nome + " - CNPJ: " + cnpj);
        for (String requisicao : requisicoes) {
            System.out.println(requisicao);
        }
    }
}