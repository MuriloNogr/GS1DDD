package br.com.fiap.projectaildly;

abstract class Cadastro {
    protected String nome;
    protected String endereco;

    public Cadastro(String nome, String endereco) {
        this.nome = nome;
        this.endereco = endereco;
    }
    
    public Cadastro() {
    	
    }

    public abstract void cadastrar();
}
