package br.com.fiap.projectaildly;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bem-vindo(a) ao Aidly!");
        System.out.println("Selecione o tipo de cadastro:");
        System.out.println("1. Ong");
        System.out.println("2. Pessoa F�sica");
        System.out.println("3. Pessoa Jur�dica");
        
        //ONGs pr�-definidas para exemplo de solicita��es
        Ong ong1 = new Ong("AACD Ibirapuera", "Av. Prof. Ascendino Reis 724", "60.979.457/0001-11");
        ong1.requisicaoExemplo("Necessita de: Alimentos n�o pereciveis");
        
        Ong ong2 = new Ong("M�os Que Aben�oam", "Rua Nazaret 1296", "18.805.439/0001-57");
        ong2.requisicaoExemplo("Necessita de: Leite em p� e blusas de frio");
        
        Ong ong3 = new Ong("Banco de Alimentos", "Rua Atibaia 218", "02.736.449/0001-48");
        ong3.requisicaoExemplo("Necessita de: Arroz");
        
        Ong ong4 = new Ong("EPAV", "Av. das Na��es 87", "29.695.107/0001-83");
        ong4.requisicaoExemplo("Roupas e alimentos em geral");
        
        Ong ong5 = new Ong("Erguendo Vidas", "Rua Catune 33", "21.021.259/0001-99");
        ong5.requisicaoExemplo("Alimentos e contribui��es monet�rias");

        int opcao = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Informe o nome: ");
        String nome = scanner.nextLine();
        System.out.print("Informe o endere�o: ");
        String endereco = scanner.nextLine();

        switch (opcao) {
            case 1:
                System.out.print("Informe o CNPJ: ");
                String cnpjOng = scanner.nextLine();

                Ong ong = new Ong(nome, endereco, cnpjOng);
                ong.cadastrar();
                ong.criarRequisicao();
                ong.imprimirRequisicoes();
                break;
            case 2:
                System.out.print("Informe o CPF: ");
                String cpf = scanner.nextLine();

                PessoaFisica pessoaFisica = new PessoaFisica(nome, endereco, cpf);
                pessoaFisica.cadastrar();

                System.out.println("Selecione o tipo de doa��o:");
                System.out.println("1. Alimentos");
                System.out.println("2. Vestimentas");
                System.out.println("3. Contribui��o Financeira");
                System.out.println("4. Exibir Solicita��es");
                

                int tipoDoacaoPF = scanner.nextInt();
                scanner.nextLine();
                String doacaoPF;


                switch (tipoDoacaoPF) {
                    case 1:
                    	System.out.print("Informe a doa��o: ");
                    	doacaoPF = scanner.nextLine();
                        pessoaFisica.fazerDoacao("Alimentos", doacaoPF);
                        pessoaFisica.imprimirDoacoes();
                        break;
                    case 2:
                    	System.out.print("Informe a doa��o: ");
                    	doacaoPF = scanner.nextLine();
                        pessoaFisica.fazerDoacao("Vestimentas", doacaoPF);
                        pessoaFisica.imprimirDoacoes();
                        break;
                    case 3:
                    	System.out.print("Informe a doa��o: ");
                    	doacaoPF = scanner.nextLine();
                        pessoaFisica.fazerDoacao("Contribui��o Financeira", doacaoPF);
                        pessoaFisica.imprimirDoacoes();
                        break;
                    case 4:
                    	ong1.imprimirRequisicoes();
                    	System.out.println("--------------------------");
                    	ong2.imprimirRequisicoes();
                    	System.out.println("--------------------------");
                    	ong3.imprimirRequisicoes();
                    	System.out.println("--------------------------");
                    	ong4.imprimirRequisicoes();
                    	System.out.println("--------------------------");
                    	ong5.imprimirRequisicoes();
                    	break;
                    default:
                        System.out.println("Op��o inv�lida!");
                        break;
                }

                break;
            case 3:
                System.out.print("Informe o CNPJ: ");
                String cnpjPessoaJuridica = scanner.nextLine();

                PessoaJuridica pessoaJuridica = new PessoaJuridica(nome, endereco, cnpjPessoaJuridica);
                pessoaJuridica.cadastrar();

                System.out.println("Selecione o tipo de doa��o:");
                System.out.println("1. Alimentos");
                System.out.println("2. Vestimentas");
                System.out.println("3. Contribui��o Financeira");
                System.out.println("4. Exibir Solicita��es");

                int tipoDoacaoPJ = scanner.nextInt();
                scanner.nextLine();

                System.out.print("Informe a doa��o: ");
                String doacaoPJ;

                switch (tipoDoacaoPJ) {
                    case 1:
                    	doacaoPJ = scanner.nextLine();
                        pessoaJuridica.fazerDoacao("Alimentos", doacaoPJ);
                        pessoaJuridica.imprimirDoacoes();
                        break;
                    case 2:
                    	doacaoPJ = scanner.nextLine();
                        pessoaJuridica.fazerDoacao("Vestimentas", doacaoPJ);
                        pessoaJuridica.imprimirDoacoes();
                        break;
                    case 3:
                    	pessoaJuridica.imprimirDoacoes();
                    	doacaoPJ = scanner.nextLine();
                        pessoaJuridica.fazerDoacao("Contribui��o Financeira", doacaoPJ);
                        break;
                    case 4:
                    	ong1.imprimirRequisicoes();
                    	System.out.println("--------------------------");
                    	ong2.imprimirRequisicoes();
                    	System.out.println("--------------------------");
                    	ong3.imprimirRequisicoes();
                    	System.out.println("--------------------------");
                    	ong4.imprimirRequisicoes();
                    	System.out.println("--------------------------");
                    	ong5.imprimirRequisicoes();
                    	break;    
                    default:
                        System.out.println("Op��o inv�lida!");
                        break;
                }

                break;
            default:
                System.out.println("Op��o inv�lida!");
                break;
        }

        scanner.close();
    }
}